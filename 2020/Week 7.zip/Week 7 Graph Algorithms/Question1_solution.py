#Question 1 solution

adjacency_list_graph = {
  'A' : ['B','C'],
  'B' : ['D', 'E'],
  'C' : ['F'],
  'D' : [],
  'E' : ['F'],
  'F' : []}

adjacency_matrix_graphe = [[0,1,1,0,0,0],
                           [0,0,0,1,1,0],
                           [0,0,0,0,0,1],
                           [0,0,0,0,0,0],
                           [0,0,0,0,0,1],
                           [0,0,0,0,0,0]]

